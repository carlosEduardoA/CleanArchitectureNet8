namespace CleaArchitecture.Domain.Vehiculos;

public record Vin(string Value);