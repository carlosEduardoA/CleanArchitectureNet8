namespace CleaArchitecture.Domain.Users;

public record Apellido(string Value);